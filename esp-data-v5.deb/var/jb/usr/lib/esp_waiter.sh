#!/bin/sh
# esp_data waiter v3: dynamic jbroot, poll AClient, opainject, status to /var/mobile/Library
ST=/var/mobile/Library/esp_waiter_status.txt
DYP=usr/lib/TweakInject/esp_data.dylib

JB=""
for d in /var/containers/Bundle/Application/.jbroot-*; do
  if [ -x "$d/basebin/opainject" ]; then JB="$d"; break; fi
done

if [ -z "$JB" ]; then
  echo "no jbroot found" > "$ST"
  exit 1
fi

DY="$JB/$DYP"
W="$JB/basebin/opainject"
echo "waiter start $(date) jb=$JB dy=$DY dy_exists=$([ -f "$DY" ] && echo yes || echo no)" > "$ST"

# sync dylib to appgroup view
AG2=/var/mobile/Containers/Shared/AppGroup/.jbroot-*/.jbroot
for ag in $AG2; do
  if [ -f "$DY" ] && [ -d "$ag/usr/lib/TweakInject" ]; then
    cp -f "$DY" "$ag/$DYP" 2>/dev/null
    chmod 644 "$ag/$DYP" 2>/dev/null
  fi
done

n=0
while [ $n -lt 7200 ]; do
  PID=$(ps ax 2>/dev/null | grep -i AClient | grep -v grep | awk '{print $1}' | head -1)
  if [ -n "$PID" ]; then
    echo "found AClient pid=$PID $(date), injecting..." >> "$ST"
    "$W" "$PID" "$DY" > /var/mobile/Library/esp_opa.log 2>&1
    if grep -q "Got task port" /var/mobile/Library/esp_opa.log 2>/dev/null; then
      echo "injected pid=$PID $(date)" >> "$ST"
      exit 0
    fi
    echo "opa retry $n: $(tail -1 /var/mobile/Library/esp_opa.log 2>/dev/null)" >> "$ST"
  fi
  if [ $((n % 30)) -eq 0 ]; then
    echo "poll $n $(date) no AClient" >> "$ST"
  fi
  n=$((n+1))
  sleep 2
done
echo "timeout after 4h" >> "$ST"
