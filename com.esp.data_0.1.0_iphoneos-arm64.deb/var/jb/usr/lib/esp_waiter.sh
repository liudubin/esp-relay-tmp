#!/bin/sh
# esp_data waiter: poll AClient pid, opainject when found
JB1=/var/containers/Bundle/Application/.jbroot-D0277C36B9A56CCD
JB2=/var/mobile/Containers/Shared/AppGroup/.jbroot-D0277C36B9A56CCD/.jbroot
DY=usr/lib/TweakInject/esp_data.dylib
W=$JB1/basebin/opainject

if [ -f "$JB1/$DY" ] && [ -d "$JB2/usr/lib/TweakInject" ]; then
  cp -f "$JB1/$DY" "$JB2/$DY"
  chmod 644 "$JB2/$DY"
fi

n=0
while [ $n -lt 3600 ]; do
  PID=$(ps ax 2>/dev/null | grep -i AClient | grep -v grep | awk '{print $1}' | head -1)
  if [ -n "$PID" ]; then
    if [ -x "$W" ]; then
      "$W" "$PID" "$JB1/$DY" >/tmp/esp_opa.log 2>&1
      if grep -q "Got task port" /tmp/esp_opa.log 2>/dev/null; then
        echo "injected pid=$PID" >/tmp/esp_opa.done
        exit 0
      fi
      echo "opa fail: $(cat /tmp/esp_opa.log 2>/dev/null)" >>/tmp/esp_opa.err
    else
      echo "opainject missing at $W" >/tmp/esp_opa.err
      exit 1
    fi
  fi
  n=$((n+1))
  sleep 2
done
echo "timeout: no AClient found in 2h" >/tmp/esp_opa.err
